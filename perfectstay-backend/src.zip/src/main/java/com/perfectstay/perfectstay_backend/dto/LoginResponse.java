package com.perfectstay.perfectstay_backend.dto;

public class LoginResponse {

    private String message;
    private String userType;
    private Long userId;

    public LoginResponse(String message, String userType, Long userId) {
        this.message = message;
        this.userType = userType;
        this.userId = userId;
    }

    public String getMessage() { return message; }
    public String getUserType() { return userType; }
    public Long getUserId() { return userId; }
}
