package com.perfectstay.perfectstay_backend.entity.enums;

public enum PaymentMethodType {
    CREDIT_CARD,
    DEBIT_CARD,
    GCASH,
    CASH
}
