package com.perfectstay.perfectstay_backend.service;

public class HotelOwnerService {
  
}
