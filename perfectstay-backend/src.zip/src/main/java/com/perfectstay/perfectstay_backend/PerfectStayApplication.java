package com.perfectstay.perfectstay_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PerfectStayApplication {

	public static void main(String[] args) {
		SpringApplication.run(PerfectStayApplication.class, args);
	}

}
