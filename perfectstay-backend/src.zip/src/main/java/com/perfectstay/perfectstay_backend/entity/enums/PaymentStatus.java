package com.perfectstay.perfectstay_backend.entity.enums;

public enum PaymentStatus {
    PAID,
    FAILED,
    PENDING,
    REFUNDED
}